import random
import io
import base64
import matplotlib.pyplot as plt
from django.shortcuts import render, redirect
from django.utils import timezone

# 단어 딕셔너리
word_dict = {
    'actor': '배우',
    'sound': '소리',
    'hurry': '서두르다',
    'raise': '올리다',
    'solve': '해결하다',
    'touch': '만지다',
    'space': '공간',
    'knock': '노크하다',
    'relax': '휴식을 취하다',
    'worry': '걱정하다',
    'sword': '검',
    'throw': '던지다',
    'voice': '목소리',
    'avoid': '피하다',
    'heavy': '무거운',
    'shout': '소리치다',
    'stage': '무대',
    'blood': '피',
    'bring': '가져오다',
    'crowd': '군중',
    'fresh': '신선한',
    'merry': '즐거운',
    'peace': '평화',
    'price': '가격',
    'guest': '손님',
    'jewel': '보석',
    'sight': '시야',
    'skill': '기술',
    'steal': '훔치다',
    'thief': '도둑',
    'front': '앞',
    'crazy': '미친',
    'niece': '조카딸',
    'sense': '감각',
    'prize': '상',
    'blank': '빈',
    'dozen': '다스',
    'ocean': '대양',
    'smell': '냄새',
    'reach': '도달하다',
    'pride': '자부심',
    'basic': '기본적인',
    'shake': '흔들다',
    'solar': '태양의',
    'taste': '맛',
    'think': '생각하다',
    'build': '짓다',
    'spend': '쓰다',
    'board': '판자',
    'count': '세다',
    'greet': '인사하다',
    'tough': '힘든',
    'whole': '전체의',
    'giant': '거인',
    'coast': '해안',
    'royal': '왕의',
    'wrong': '잘못된',
    'sweat': '땀',
    'swing': '그네',
    'blind': '눈이 먼',
    'cross': '십자가',
    'fairy': '요정',
    'shine': '빛나다',
    'brush': '붓',
    'clerk': '점원',
    'float': '떠오르다',
    'glory': '영광',
    'thick': '두꺼운',
    'slide': '미끄러지다',
    'admit': '인정하다',
    'habit': '습관',
    'ready': '준비된',
    'spell': '철자를 쓰다',
    'cough': '기침하다',
    'title': '제목',
    'truth': '진실',
    'allow': '허락하다',
    'metal': '금속',
    'guide': '안내하다',
    'chief': '우두머리',
    'sheet': '시트',
    'broad': '넓은',
    'focus': '집중하다',
    'point': '점',
    'smoke': '연기',
    'above': '위에',
    'spicy': '매운',
    'wheel': '바퀴',
    'flash': '번쩍이다',
    'rumor': '소문',
    'quick': '빠른',
    'usual': '평소의',
    'noisy': '시끄러운',
    'agree': '동의하다',
    'proud': '자랑스러운',
    'quite': '꽤',
    'funny': '재미있는',
    'tight': '꽉 끼는',
    'pilot': '조종사',
    'topic': '주제',
}

# 단어 리스트에서 무작위로 선택하기 위한 키 리스트
WORDS = list(word_dict.keys())

def index(request):
    if 'word' not in request.session:
        request.session['word'] = random.choice(WORDS)
        request.session['attempts'] = 6
        request.session['previous_attempts'] = []
        request.session['start_time'] = timezone.now().isoformat()

    word = request.session['word']
    attempts_left = request.session['attempts']
    previous_attempts = request.session['previous_attempts']

    message = ''
    elapsed_time = None
    congratulations_message = None
    congratulations_image = None  # 초기값을 None으로 설정

    if request.method == 'POST':
        if 'guess' in request.POST:
            guess = request.POST['guess']
            if len(guess) != 5:
                message = "단어는 5글자여야 합니다. 5글자 이상 입력하면 앞에서부터 5글자만 잘라 게임이 진행됩니다."
            else:
                feedback = get_feedback(guess, word)
                request.session['previous_attempts'].append((guess, feedback))
                if guess == word:
                    elapsed_time = (timezone.now() - timezone.datetime.fromisoformat(request.session['start_time'])).seconds
                    congratulations_message = f"축하합니다! 정답은 '{word}'이었습니다. 뜻은 '{word_dict[word]}'입니다. {elapsed_time}초 만에 맞추셨습니다!"

                    congratulations_image = draw_congratulations()
                    del request.session['word']
                    return render(request, 'game/index.html', {
                        'congratulations_message': congratulations_message,
                        'congratulations_image': congratulations_image,
                        'hangman_image': None  # 축하 이미지가 출력되므로, 행맨 이미지를 None으로 설정
                    })
                else:
                    request.session['attempts'] -= 1
                    attempts_left = request.session['attempts']
                    if attempts_left == 0:
                        message = f"게임 오버! 정답은 '{word}'이었습니다. 뜻은 '{word_dict[word]}'입니다."
                        del request.session['word']
                        elapsed_time = (timezone.now() - timezone.datetime.fromisoformat(request.session['start_time'])).seconds
                        hangman_image = draw_hangman(6)
                        return render(request, 'game/index.html', {
                            'message': message,
                            'elapsed_time': elapsed_time,
                            'hangman_image': hangman_image,
                            'congratulations_message': None,  # 게임 오버이므로 축하 메시지를 None으로 설정
                            'congratulations_image': None  # 게임 오버이므로 축하 이미지를 None으로 설정
                        })
    if not elapsed_time:
        elapsed_time = (timezone.now() - timezone.datetime.fromisoformat(request.session['start_time'])).seconds

    if 'word' in request.session and request.session['attempts'] > 0:
        hangman_image = draw_hangman(6 - attempts_left)
    else:
        hangman_image = None  # 문제를 맞췄거나 게임 오버이면 행맨 이미지를 None으로 설정

    return render(request, 'game/index.html', {
        'attempts': attempts_left,
        'previous_attempts': previous_attempts,
        'message': message,
        'elapsed_time': elapsed_time,
        'hangman_image': hangman_image,
        'congratulations_message': congratulations_message,
        'congratulations_image': congratulations_image
    })


def get_feedback(guess, word):
    feedback = []
    for g, w in zip(guess, word):
        if g == w:
            feedback.append('🟩')
        elif g in word:
            feedback.append('🟨')
        else:
            feedback.append('⬛')
    return ''.join(feedback)

def reset_game(request):
    if 'word' in request.session:
        del request.session['word']
    return redirect('index')

def draw_hangman(stage):
    stages = [
        """
        +---+
            |
            |
            |
           ===
        """,
        """
        +---+
        O   |
            |
            |
           ===
        """,
        """
        +---+
        O   |
        |   |
            |
           ===
        """,
        """
        +---+
        O   |
       /|   |
            |
           ===
        """,
        """
        +---+
        O   |
       /|\  |
            |
           ===
        """,
        """
        +---+
        O   |
       /|\  |
       /    |
           ===
        """,
        """
        +---+
        O   |
       /|\  |
       / \  |
           ===
        """,
    ]
    
    fig, ax = plt.subplots(figsize=(3, 3))
    ax.text(0.5, 0.5, stages[stage], fontsize=20, va='center', ha='center', fontfamily='monospace')
    ax.axis('off')

    # Save image to a BytesIO object
    buf = io.BytesIO()
    fig.savefig(buf, format='png')
    buf.seek(0)

    # Encode image to base64 string
    string = base64.b64encode(buf.read())
    uri = 'data:image/png;base64,' + string.decode('utf-8')

    return uri

def draw_congratulations():
    stage = """
         
    O   
   \\|/  
    |   
   / \\  
  Congratulations!
"""
    fig, ax = plt.subplots(figsize=(4, 4))
    ax.text(0.5, 0.5, stage, fontsize=20, va='center', ha='center', fontfamily='monospace')
    ax.axis('off')

    # Save image to a BytesIO object
    buf = io.BytesIO()
    fig.savefig(buf, format='png')
    buf.seek(0)

    # Encode image to base64 string
    string = base64.b64encode(buf.read())
    uri = 'data:image/png;base64,' + string.decode('utf-8')

    return uri
