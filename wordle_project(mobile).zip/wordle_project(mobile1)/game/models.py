from django.db import models


class Game(models.Model):
    # 게임과 관련된 필드 정의
    pass

# 예시 초기화 함수
def initialize_game_data():
    Game.objects.all().delete()
    # 필요한 초기 데이터 생성
# Create your models here.
