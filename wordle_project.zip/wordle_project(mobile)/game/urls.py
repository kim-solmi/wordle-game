from django.urls import path
from . import views

urlpatterns = [
    # 기존 URL 패턴
    path('', views.index, name='index'),
    # 초기화 URL 패턴 추가
    path('reset/', views.reset_game, name='reset_game'),
]
